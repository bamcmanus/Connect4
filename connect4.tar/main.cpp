#include "c4.h"
#include "board.h"
#include "player.h"

using namespace std;

int main()
{
  Connect4 game;
  game.play();
}
